//
//  RateView.swift
//  prankd
//
//  Created by jody on 24/04/26.
//

import SwiftUI

struct RateView: View {
    var body: some View {
        Text("i wasn't able to complete this on time TT")
    }
}

#Preview {
    RateView()
}
