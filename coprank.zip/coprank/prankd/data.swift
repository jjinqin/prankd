//
//  data.swift
//  prank call
//
//  Created by Aileen Jane on 20/04/26.
//

import Foundation

enum Role {
    case player
    case victim
}

struct ContactModel: Identifiable, Equatable {
    var id = UUID()
    var firstName: String
    var phoneNumber: String? ///make optional
    var imageName: String?
    var role: Role
}

var chandra = ContactModel (firstName: "Chandra", phoneNumber: "08999999999", imageName: "women 5", role: .player)
var jody: ContactModel = ContactModel(firstName: "Jody", phoneNumber: "0811111111", imageName: "women 1", role: .player)
var sam = ContactModel(firstName: "Sam", phoneNumber: "0822222222", imageName: "women 2", role: .player)
var virel = ContactModel (firstName: "Virel", phoneNumber: "0833333333", imageName: "women 3", role: .player)
var ish = ContactModel (firstName: "Ish", phoneNumber: "0844444444", imageName: "men 1", role: .player)
var nathan = ContactModel (firstName: "Nathan", phoneNumber: "0855555555", imageName: "men 2", role: .victim)
var baeni = ContactModel (firstName: "Baeni", phoneNumber: "0866666666", imageName: "women 4", role: .victim)
var javi = ContactModel (firstName: "Javier", phoneNumber: "0877777777", imageName: "men 3", role: .victim)

//struct myVal : Equatable {
//    let id = UUID()
//    let val: String
//}
