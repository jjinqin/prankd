//
//  ContentView.swift
//  prankd
//
//  Created by jody on 19/04/26.
//

import SwiftUI

struct ContentView: View {
    @State var degree = 360.0
    let victims: [ContactModel]
    //MARK: - player data
    
//    let array : [myVal] =  [myVal(val: "aileen"),
//                            myVal(val: "sam"),
//                            myVal(val: "juno"),
//                            myVal(val: "baeni"),
//                            myVal(val: "william"),
//                            myVal(val: "frans"),
//                            myVal(val: "talin"),
//                            myVal(val: "gusti"),
//                            myVal(val: "nathan"),
//                            myVal(val: "javier")]
//    
    var body: some View {
        NavigationStack {
            ZStack (alignment: .center){
                Color.black.ignoresSafeArea()
                
                WheelView(degree: $degree, victims: victims, circleSize: 615)
                    .offset(x: -200)
            }
        }
        .padding(.top, -120)
        .preferredColorScheme(.dark)
    }
}


//#Preview {
//    ContentView()
//}
