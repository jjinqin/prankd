//
//  PrankView.swift
//  prankd
//
//  Created by jody on 22/04/26.
//


import SwiftUI

//MARK: - state and environment properties
struct PrankView: View {
    @Environment(\.dismiss) var dismiss
    @State var value: Double = 0
//    @State var navigate: Bool = false
    @State var isConfirmed = false
    
    let chosen: ContactModel
    
    //MARK: - whole view
    var body: some View {
        NavigationStack {
            ZStack {
                VStack {
                    
                    Text("choose your prank")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("calling \(chosen.firstName)")
                        .font(.subheadline)
                    
                    ///how bad is the prank stack
                    VStack {
                        ///customizes the slider based on the steps
                        Slider(value: $value, in: 0...4, step: 1).disabled(isConfirmed)
                        ///hardcoded this shit because i tried and it wasn't showing UP.
                        HStack {
                            Text("💩")
                            Spacer()
                            Text("🫢")
                            Spacer()
                            Text("🫣")
                            Spacer()
                            Text("🤪")
                            Spacer()
                            Text("😈")
                        }
                    }
                    .padding( .horizontal, 30)
                    .padding(.bottom, 25)
                    .tint(.white)
                    
                    ///to include a done button to activate flip the card
                    ///kinda redundant might remove ~
                    Button("done", role: .confirm) {
                        isConfirmed = true
                    }
                    .buttonStyle(.bordered)
                    .foregroundStyle(.white)

                    //MARK: - start of card
                    ///insert card ui here
                    if isConfirmed {
                        Card(flip: false, value: $value)
                    }

                    //MARK: end of card -
                }
            }
            .toolbar {
                ///bottom bar items
                ToolbarItemGroup(placement: .bottomBar) {
                    Button {
                        dismiss()
                    } label: {
                        Label("Back", systemImage: "chevron.left")
                    }

                    NavigationLink {
                        Screen6(top3: [
                            RankedPlayer(contact: jody, score: 5400),
                            RankedPlayer(contact: sam, score: 5000),
                            RankedPlayer(contact: virel, score: 4800),
                            RankedPlayer(contact: nathan, score: 3000),
                            RankedPlayer(contact: baeni, score: 2000),
                            RankedPlayer(contact: ish, score: 1000)
                        ],
                                players: [
                                    RankedPlayer(contact: jody, score: 5400),
                                    RankedPlayer(contact: sam, score: 5000),
                                    RankedPlayer(contact: virel, score: 4800),
                                    RankedPlayer(contact: nathan, score: 3000),
                                    RankedPlayer(contact: baeni, score: 2000),
                                    RankedPlayer(contact: ish, score: 1000)
                                ])
                    } label: {
                        Label("Next", systemImage: "chevron.right")
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

//#Preview {
//    PrankView(chosen: chosen?.val)
//        .preferredColorScheme(.dark)
//}
