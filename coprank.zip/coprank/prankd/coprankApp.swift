//
//  coprankApp.swift
//  prankd
//
//  Created by jody on 19/04/26.
//

import SwiftUI

@main
struct coprankApp: App {
    var body: some Scene {
        WindowGroup {
            Screen1Player(
                players: ([
                    ContactModel(firstName: "Jody", phoneNumber: "123", imageName: "men 1", role: .player),
                    ContactModel(firstName: "Sam", phoneNumber: "456", imageName: "men 2", role: .player),
                    ContactModel(firstName: "Virel", phoneNumber: "789", imageName: "men 3", role: .player),
                    ContactModel(firstName: "Alex", phoneNumber: "222", imageName: "women 3", role: .player)
                ]),
                victims: ([
                    ContactModel(firstName: "Ish", phoneNumber: "000", imageName: "women 1", role: .player),
                    ContactModel(firstName: "Chandra", phoneNumber: "111", imageName: "women 2", role: .player),
                    ContactModel(firstName: "Nathan", phoneNumber: "999", imageName: "men 1", role: .victim)
                ])
            )
//            ContentView()
        }
    }
}
