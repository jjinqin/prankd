//
//  WheelView.swift
//  prankd
//
//  Created by jody on 19/04/26.
//

import SwiftUI

//MARK: - the data i want inside the view

enum Direction {
    case down
    case up
}

//MARK: - the view with variables (i.e. my wheel)
struct WheelView: View {
    ///circle radius
    @State var radius: Double = 150
    ///direction of the drag gesture
    @State var direction = Direction.down
    ///used to lock the view of the wheel afterwards, allowing for a single spin
    @State var isSpinning: Bool = false
    ///a property to hold the selected name (or victim)
    @State var chosen: ContactModel? = nil /// no value exists
    ///drives the swiftui navigation to the next view (PrankView)
    @State var navigate: Bool = false
    ///degree of circle
    @Binding var degree : Double
    
    let victims : [ContactModel]
    let circleSize : Double
    
    /// how big is each slice of the wheel
    var segmentAngle : Double { 360 / Double(victims.count) }
    var selectedIndexAtSide: Int {
        /// guard against the condition (!array.isEmpty), so if it fails return 0
        guard !victims.isEmpty else { return 0 }
        /// when degree == 0, index 0 is at the top.
        /// as degree increases (clockwise rotation), the selected index moves backwards, so we negate degree to compensate -> fixes the mismatch
        let raw = Int(round((-degree) / segmentAngle))
        /// safe modulo to handle negative values
        return ((raw % victims.count) + victims.count) % victims.count
    }

    //MARK: - function to spin the wheel
    ///take the current rotation and add more spin to it, land at the correct slice
    func spinWheel() {
        ///guard against the condition (!isSpinning), so do nothing if it's spinning
        guard !isSpinning else { return }
        isSpinning = true
        
        let segment = 360 / Double(victims.count)
        let spins = 8 * 360.0
        let chosenIndex = Int.random(in: 0..<victims.count)
        
        withAnimation(.easeOut(duration: 3.0)) {
            degree += spins - Double(chosenIndex) * segment
        }
        
        ///wait for the animation to finish before showing the results
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            /// this code runs after the wheel stops spinning
            /// compute the chosen index after the rotation
            let index = selectedIndexAtSide
            chosen = victims[index]
            navigate = true
        }
    }
    
    //MARK: - gestures for the wheel
    
    var body: some View {
        ZStack {
            /// to separate the names based on their angle
            let anglePerCount = Double.pi * 2.0 / Double(victims.count)
            let drag = DragGesture()
                .onEnded { value in
                    if value.startLocation.x > value.location.x + 10 {
                        direction = .down
                    }
                    else if value.startLocation.x < value.location.x - 10 {
                        direction = .up
                    }
                    spinWheel()
                }

            // MARK: - spinning wheel
            ZStack {
                Circle().fill(.gray.opacity(0.4))
                /// getting the numerical positions of items during a loop
                ForEach(victims.indices, id: \.self) { index in
                    let angle = Double(index) * anglePerCount
                    ///x- and y-coordinate of the circle
                    let xOffset = CGFloat(radius * cos(angle))
                    let yOffset = CGFloat(radius * sin(angle))
                    ///check if the current item we're looping over is the selected index
                    let isChosen = index == selectedIndexAtSide
                    Text("\(victims[index].firstName)")
                        .rotationEffect(Angle(degrees: -degree))
                        .offset(x: xOffset, y: yOffset )
                        .font(Font.system(isChosen ? .title : .body))
                        .fontWeight(isChosen ? .bold : .regular)
                    
                    ///to stop it from being spinable + move it to the next screen
                    
                }
            }
            .rotationEffect(Angle(degrees: degree))
            .gesture(drag)
            .onAppear() {
                let labelPadding : Double = 60
                radius = circleSize/2 - labelPadding
                
                isSpinning = false
            }
            
            //MARK: - pointer
            ZStack {
                Image(systemName: "arrowtriangle.left.fill")
            }
            .offset(x: 310)
            
            // MARK: - adjustments to current view
        }
        .frame(width: circleSize, height: circleSize)
        /// top bar items
        .navigationTitle("spin the wheel!")
        .navigationBarTitleDisplayMode(.large)
        .navigationSubtitle("choose your victim")
        .navigationBarBackButtonHidden(true)
        .toolbar {
//            ToolbarItem(placement: .largeSubtitle) {
//                Text("who's your next victim?")
//                    .frame(maxWidth: .infinity, alignment: .leading)
//            }
            
            ///bottom bar items
            ToolbarItemGroup(placement: .bottomBar) {
                ///back action to add more or delete if someone changes their mind
                Button {
                } label: {
                    Label("Back", systemImage: "chevron.left")
                }
                
                /// navigation link to the next page, once we have a chosen value
                if navigate, let chosen {
                    NavigationLink {
                        PrankView(chosen: chosen)
                    } label: {
                        Label("Next", systemImage: "chevron.right")
                    }
                }
            }
        }
    }
}
    
//    #Preview {
//        ContentView()
//    }
    
