//
//  Card.swift
//  prankd
//
//  Created by jody on 22/04/26.
//

import SwiftUI

//MARK: - the data i want inside the card view
struct cardModel: Identifiable {
    let id = UUID()
    let header: String
    let prank: String
    let emoji: String
}

//MARK: - card view
struct Card: View {
    ///creates a state property called flip that allows the view to manage its state
    @State var flip = false
    @Binding var value: Double
    
    var body: some View {
        ZStack {
            /// rotates by 90 degrees when the card is not flipped and returns to 0 degrees when it is flipped
            CardFrontView(flip: $flip)
                .rotation3DEffect(.degrees(flip ? 90: 0), axis: (x: 0, y: -1, z: 0))
            /// controls the timing of the animation, so that there is a smooth transition between both sides
                .animation(flip ? .linear : .linear.delay(0.35), value: flip)
            /// behaves the opposite way to the front view
            CardBackView(flip: $flip, value: $value)
                .rotation3DEffect(.degrees(flip ? 0 : -90), axis: (x: 0, y: -1, z: 0))
                .animation(flip ? .linear.delay(0.35) : .linear, value: flip)
        }
        /// when the user taps the screen the flip state toggles between true and false, triggering the animation
        .onTapGesture {
            flip.toggle()
        }
    }
}

//MARK: - front view
struct CardFrontView: View {
    ///passing the flip state from the parent view (top) and the child views
    @Binding var flip: Bool
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
            
            Text("tap to flip")
                .font(.title)
                .fontWeight(.bold)
                .foregroundStyle(.black)
        }
        .padding(.vertical, 20)
        .padding(.horizontal, 20)
        .frame(width: 375, height: 400)
    }
}


//MARK: - back view/poop
struct CardBackView: View {
    
        let cards: [cardModel] = [
            cardModel(header: "can i call you back?", prank: "call your ex and pretend that they called you. start the conversation by saying: hey, sorry. i'm really busy, can i call you later?", emoji: "☎️"),
            cardModel(header: "fake pizza", prank: "tell the person you ordered pizza two hours ago and that you checked the entire neighbourhood but it's nowhere to be seen.", emoji: "🍕"),
            cardModel(header: "time traveler", prank: "insist you are them from the future and warn them about what is coming.", emoji: "⏰"),
            cardModel(header: "congratulations!", prank: "pretend to be their favourite celebrity, youtuber, influencer, or brand.", emoji: "🥳"),
            cardModel(header: "selamat malam :p", prank: "wait till 3 am, use a voice changer and just say hello and stay silent. \n(can't wait to hear them scream!)", emoji: "😈"),
        ]
    
    @Binding var flip: Bool
    @Binding var value: Double ///to 'link' the slider values to one of the arrays
    
    var body: some View {
            ZStack(alignment: .top) {
                RoundedRectangle(cornerRadius: 20)
                
                VStack(alignment: .center) {
                    Text(cards[Int($value.wrappedValue)].header)
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text(cards[Int($value.wrappedValue)].prank)
                        .font(.default)
                        .padding(.horizontal)
                }
                .padding(.top, 40)
                .multilineTextAlignment(.center)
                .foregroundStyle(.black)
                
                Text(cards[Int($value.wrappedValue)].emoji)
                    .font(.system(size: 100))
                    .position(x: 260,y: 280 )
            }
            .padding(.vertical, 20)
            .padding(.horizontal, 20)
            .frame(width: 375, height: 400)
        }
    }

//#Preview {
//    PrankView()
//        .preferredColorScheme(.dark)
//}
